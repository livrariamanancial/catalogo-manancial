import { Product, StoreSettings, BlingConfig, FilterState, CartItem, CustomerOrderData } from '../types';
import { INITIAL_PRODUCTS, INITIAL_STORE_SETTINGS, INITIAL_BLING_CONFIG } from '../data/initialCatalog';

export async function fetchCatalog(filters?: Partial<FilterState>): Promise<{ products: Product[]; total: number; lastSyncAt?: string }> {
  try {
    const params = new URLSearchParams();
    if (filters?.search) params.append('search', filters.search);
    if (filters?.category && filters.category !== 'todos') params.append('category', filters.category);
    if (filters?.subcategory) params.append('subcategory', filters.subcategory);
    if (filters?.inStockOnly) params.append('inStockOnly', 'true');
    if (filters?.minPrice) params.append('minPrice', filters.minPrice.toString());
    if (filters?.maxPrice) params.append('maxPrice', filters.maxPrice.toString());
    if (filters?.publisher) params.append('publisher', filters.publisher);
    if (filters?.format) params.append('format', filters.format);
    if (filters?.sortBy) params.append('sortBy', filters.sortBy);

    const response = await fetch(`/api/products?${params.toString()}`);
    if (!response.ok) throw new Error('Falha ao carregar produtos');
    return await response.json();
  } catch (error) {
    console.warn('Usando catálogo local em cache:', error);
    let filtered = [...INITIAL_PRODUCTS];

    if (filters?.search) {
      const q = filters.search.toLowerCase();
      filtered = filtered.filter(p => p.name.toLowerCase().includes(q) || p.author.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q));
    }
    if (filters?.category && filters.category !== 'todos') {
      filtered = filtered.filter(p => p.category === filters.category);
    }
    if (filters?.inStockOnly) {
      filtered = filtered.filter(p => p.stock > 0);
    }
    return {
      products: filtered,
      total: filtered.length,
      lastSyncAt: new Date().toISOString(),
    };
  }
}

export async function fetchStoreConfig(): Promise<{ store: StoreSettings; bling: BlingConfig }> {
  try {
    const response = await fetch('/api/config');
    if (!response.ok) throw new Error('Falha ao buscar configurações');
    return await response.json();
  } catch (error) {
    return {
      store: INITIAL_STORE_SETTINGS,
      bling: INITIAL_BLING_CONFIG,
    };
  }
}

export async function updateStoreConfig(payload: { store?: Partial<StoreSettings>; bling?: Partial<BlingConfig> }): Promise<{ success: boolean; store: StoreSettings; bling: BlingConfig }> {
  const response = await fetch('/api/config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error('Falha ao atualizar configurações');
  return await response.json();
}

export async function testBlingConnectionApi(token?: string): Promise<{ success: boolean; message: string; latencyMs: number; details?: any }> {
  const response = await fetch('/api/bling/test-connection', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token }),
  });
  return await response.json();
}

export async function triggerBlingSync(): Promise<{ success: boolean; message: string; updatedCount: number; timestamp: string }> {
  const response = await fetch('/api/bling/sync', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  });
  return await response.json();
}

export async function fetchBlingAuthUrl(): Promise<{ url: string; redirectUri: string; clientId: string }> {
  const response = await fetch('/api/bling/auth-url');
  if (!response.ok) throw new Error('Falha ao obter URL de autenticação');
  return await response.json();
}

export async function updateStockSimulation(skuOrId: string, stock: number): Promise<{ success: boolean; product: Product; message: string }> {
  const response = await fetch('/api/bling/update-stock', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sku: skuOrId, stock }),
  });
  return await response.json();
}

/**
 * Generate formatted WhatsApp URL and message payload for Cart order
 */
export function generateWhatsAppOrderUrl(
  items: CartItem[],
  storeSettings: StoreSettings,
  customerData?: Partial<CustomerOrderData>
): string {
  const rawPhone = (storeSettings?.whatsappNumber || '5511998765432').replace(/\D/g, '');
  const phone = rawPhone.startsWith('55') ? rawPhone : `55${rawPhone}`;

  const subtotal = items.reduce((acc, item) => acc + (item.product.promotionalPrice || item.product.price) * item.quantity, 0);
  const totalItemsCount = items.reduce((acc, item) => acc + item.quantity, 0);

  const orderTypeLabels: Record<string, string> = {
    pickup: 'Retirada no Balcão (Loja Física)',
    retirada: 'Retirada no Balcão (Loja Física)',
    delivery: 'Entrega / Motoboy',
    entrega: 'Entrega / Motoboy',
    shipping: 'Envio por Correios / Transportadora',
    frete_a_combinar: 'Envio por Correios / Transportadora',
  };

  const paymentLabels: Record<string, string> = {
    pix: 'PIX (Chave da Livraria)',
    card: 'Cartão (Débito/Crédito)',
    cartao_credito: 'Cartão de Crédito',
    cartao_debito: 'Cartão de Débito',
    cash: 'Dinheiro na Entrega/Retirada',
    dinheiro: 'Dinheiro na Entrega/Retirada',
    a_combinar: 'A Combinar com Atendente',
  };

  let message = `*NOVO PEDIDO - ${(storeSettings?.storeName || 'LIVRARIA MANANCIAL').toUpperCase()}*\n`;
  message += `_Catálogo Online & Consulta de Estoque Bling_\n\n`;

  if (customerData?.customerName) {
    message += `👤 *Cliente:* ${customerData.customerName}\n`;
  }
  if (customerData?.customerPhone) {
    message += `📞 *Telefone:* ${customerData.customerPhone}\n`;
  }
  if (customerData?.orderType) {
    message += `📦 *Forma de Recebimento:* ${orderTypeLabels[customerData.orderType] || customerData.orderType}\n`;
  }
  if (customerData?.deliveryAddress) {
    message += `📍 *Endereço de Entrega:* ${customerData.deliveryAddress}\n`;
  }
  if (customerData?.paymentMethod) {
    message += `💳 *Forma de Pagamento:* ${paymentLabels[customerData.paymentMethod] || customerData.paymentMethod}\n`;
  }
  message += `\n`;

  message += `📚 *ITENS DO PEDIDO (${totalItemsCount} ${totalItemsCount === 1 ? 'item' : 'itens'}):*\n`;
  message += `───────────────────────\n`;

  items.forEach((item, index) => {
    const p = item.product;
    const unitPrice = p.promotionalPrice || p.price;
    const lineTotal = unitPrice * item.quantity;
    message += `*${index + 1}.* ${p.name}\n`;
    message += `   • Cód. Bling: \`${p.sku}\`\n`;
    if (p.versionOrTranslation) {
      message += `   • Versão: ${p.versionOrTranslation}\n`;
    }
    if (p.format) {
      message += `   • Acabamento: ${p.format}\n`;
    }
    message += `   • Qtd: *${item.quantity}x* de R$ ${unitPrice.toFixed(2).replace('.', ',')}`;
    message += ` = *R$ ${lineTotal.toFixed(2).replace('.', ',')}*\n\n`;
  });

  message += `───────────────────────\n`;
  message += `💰 *VALOR TOTAL: R$ ${subtotal.toFixed(2).replace('.', ',')}*\n`;

  if (customerData?.notes && customerData.notes.trim()) {
    message += `\n📝 *Observações:* ${customerData.notes.trim()}\n`;
  }

  message += `\n_Por favor, confirme a disponibilidade e os dados para pagamento. Obrigado!_`;

  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

/**
 * Generate a single item WhatsApp inquiry URL
 */
export function generateSingleProductWhatsAppUrl(
  product: Product,
  storeSettings: StoreSettings
): string {
  const rawPhone = (storeSettings.whatsappNumber || '5511998765432').replace(/\D/g, '');
  const phone = rawPhone.startsWith('55') ? rawPhone : `55${rawPhone}`;
  const price = product.promotionalPrice || product.price;

  let message = `Olá, *${storeSettings.storeName}*!\n`;
  message += `Gostaria de informações e verificar a disponibilidade do seguinte item do catálogo:\n\n`;
  message += `📖 *${product.name}*\n`;
  message += `• Código Bling: \`${product.sku}\`\n`;
  message += `• Autor: ${product.author}\n`;
  message += `• Editora: ${product.publisher}\n`;
  if (product.versionOrTranslation) {
    message += `• Versão: ${product.versionOrTranslation}\n`;
  }
  message += `• Preço no Catálogo: R$ ${price.toFixed(2).replace('.', ',')}\n`;
  message += `• Estoque Informado: ${product.stock > 0 ? `${product.stock} un. disponíveis` : 'Consultar previsão'}\n\n`;
  message += `Poderia me informar como posso realizar a reserva/compra?`;

  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}
